class SimpleCache:
    def get(self, endpoint, checksum=""):
        return None

    def set(self, endpoint, data, checksum="", expiration=None):
        pass
